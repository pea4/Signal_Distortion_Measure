#include "stm32f10x.h"

int main(void){
    /*添加程序*/
    while(1){
        /*添加循环程序*/
    }
}
